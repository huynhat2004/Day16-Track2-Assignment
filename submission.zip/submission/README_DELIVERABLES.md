# Lab 16 AWS - Deliverables

- benchmark.py: code benchmark đã chạy trên VM.
- benchmark_result.json: kết quả benchmark đầy đủ.
- screenshots/terminal: ảnh lệnh chạy benchmark và kết quả.
- screenshots/resources: ảnh CPU/RAM/Network.
- screenshots/billing: ảnh AWS Billing/Cost.
- terraform/: source hạ tầng AWS đã dùng.
- report.md: báo cáo 5-10 dòng và bảng metric.

Gói nộp không chứa private key, Terraform state hoặc Kaggle credential.
